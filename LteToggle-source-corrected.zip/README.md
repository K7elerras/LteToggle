# LTE Toggle

A minimal Quick Settings Tile for realme RMX3686 (Android 14 / realme UI 5.0)
that toggles the mobile data "preferred network type" between **LTE only**
and **LTE/WCDMA/GSM**, without opening the hidden Phone info screen every
time.

## Status of this deliverable — read this first

**Correction applied:** an earlier version of this project had a compile
error (treated `setAllowedNetworkTypesForReason()`, which returns `void`,
as if it returned `boolean`) and, more importantly, a logic error (treated
"the setter didn't throw" as proof the mode actually changed). Both are
fixed now — see "How the network mode is actually changed" below. This is
exactly the kind of mistake only a real build/review catches, which is
part of why this still needs to be built and tested by you, not taken on
faith from this description.

**BUILD SUCCESSFUL: NOT PERFORMED IN THIS ENVIRONMENT.**
**DEVICE FUNCTIONALITY VERIFIED: NOT VERIFIED.**

This sandbox has no Android SDK/emulator and no network access, so I could
not run Gradle, produce a `.apk`, or compute a SHA-256 of a build artifact —
there is no artifact. What you have is a **complete, real, non-stub source
project** implementing the architecture and logic described below, ready to
open in Android Studio and build yourself. I'm telling you this plainly
because the alternative — claiming a build or on-device result I didn't
actually produce — is exactly what you told me not to do, and I'm not going
to do it.

What *is* done, and real (not pseudocode, no TODOs in the core path):
- A `TileService` that genuinely queries and toggles the mode, never fakes
  the tile state, and never blocks the main thread.
- A working mechanism for the actual privileged telephony call (see below),
  using Shizuku — not root, not a fake permission catch.
- Honest, specific failure reporting for every failure mode in Section 13
  of your spec, surfaced to both the tile and the app UI.
- A manual fallback to the hidden Phone info screen, clearly separated from
  the direct-toggle path, never invoked automatically.

## How the network mode is actually changed

`TelephonyManager.setAllowedNetworkTypesForReason(reason, bitmask)` is a
**public** Android SDK method (added API 33) — not a hidden/internal one —
but it requires `MODIFY_PHONE_STATE`, which a normal sideloaded APK cannot
hold, and **it returns `void`**: the framework gives no success/failure
signal from the call itself. An earlier version of this project incorrectly
treated "the call didn't throw" as proof of success — that was wrong and
has been fixed. Every set operation now works in two steps:

1. Call the setter. If it throws, that's a definite, immediate failure —
   nothing is claimed.
2. If it doesn't throw, independently call `getAllowedNetworkTypesForReason()`
   and compare the result to what was requested:
   - **Matches** → `VERIFIED_MATCH`, the only outcome treated as success.
   - **Doesn't match** → `VERIFIED_MISMATCH`: the framework accepted the
     call but did not end up in the requested state. Reported as a failure.
   - **Read-back itself fails** (e.g. it also needs
     `READ_PRIVILEGED_PHONE_STATE` and that check fails even for the
     shell/root process) → `VERIFIED_UNAVAILABLE`: the outcome is genuinely
     unknown and is reported as such, never as success.

This logic lives in both `DirectTelephonyController` (in-process path) and
`NetworkModeUserService`/`ShizukuTelephonyController` (Shizuku path) — see
`NetworkModeServiceResult.kt` for the shared result codes.

Even `VERIFIED_MATCH` only proves the *framework's own bookkeeping* now
reports the new bitmask — it doesn't independently prove the RIL/modem
applied it at the radio level. That last mile can only be confirmed by an
actual test on your RMX3686 (Section 21 / the test table below), which
remains the final authority on whether this works on your device at all.

The app does not request root and does not fake success. It uses:

1. **Direct path** (`DirectTelephonyController`): tries the call in-process
   first. On virtually all normal installs this is denied by the OS — that's
   expected and reported honestly, not hidden.
2. **Shizuku path** (`ShizukuTelephonyController` + `NetworkModeUserService`):
   Shizuku spawns a separate real Android process carrying the Linux UID
   that Shizuku itself runs as — `shell` (UID 2000) if started via wireless
   debugging/ADB (your case, since the device isn't rooted), or `root` if
   you ever switch to the Sui/root backend. That process calls the exact
   same public `setAllowedNetworkTypesForReason()` method, just from a
   process whose UID the framework's permission check accepts, then
   verifies the result the same way as above. This is *not* the same as
   spoofing a permission — it's Shizuku's documented, standard mechanism
   (`ShizukuBinderWrapper`/user-service model), and it's why apps like this
   don't need root.
3. **If neither works, or verification fails/is inconclusive**: the app
   reports the specific failure and offers the manual Phone info fallback —
   it never pretends the mode changed.

**One thing I deliberately did *not* do**, because it would have meant
guessing: some blog write-ups change network mode via raw
`service call phone <transaction-code> ...` shell commands. Those
transaction-code numbers are **assigned by the order methods are declared
in your specific OEM's compiled `ITelephony.aidl`**, and they differ across
Android/OEM builds — the one universal way to get them right is to pull
`/system/framework/framework.jar` (or `services.jar`) off *your* RMX3686 and
disassemble it. I don't have your device, so I didn't hardcode a guessed
number. The public-API-through-Shizuku approach above avoids that fragility
entirely, at the cost of depending on `shell`/`root` actually holding
`MODIFY_PHONE_STATE` on realme UI 5.0 — which is very likely (it's a
long-standing AOSP shell grant used by the exact `adb shell` techniques
these tools rely on) but, again, **not something I can confirm without your
device**. Test 3/4 in the plan below is exactly how you confirm it.

## Does direct switching work without root? Is Shizuku required?

- **Root: not required, not requested anywhere in this app.**
- **Shizuku: required** for the toggle to actually work on a normal,
  non-privileged install of this APK — unless you happen to install it as a
  privileged system app (out of scope here), the direct path in step 1
  above will fail and the app will fall back to Shizuku.

## Project structure

```
app/src/main/
├── AndroidManifest.xml
├── aidl/.../service/INetworkModeService.aidl   # our own IPC contract
├── java/com/localtools/ltetoggle/
│   ├── MainActivity.kt
│   ├── tile/LteToggleTileService.kt
│   ├── telephony/
│   │   ├── NetworkMode.kt                # LTE_ONLY / LTE_WCDMA_GSM bitmasks
│   │   ├── NetworkModeResult.kt
│   │   ├── NetworkModeController.kt      # decision tree (direct → Shizuku)
│   │   ├── DirectTelephonyController.kt
│   │   ├── ShizukuTelephonyController.kt
│   │   └── NetworkModeUserService.kt     # runs OUTSIDE this app's process
│   ├── shizuku/ShizukuManager.kt
│   └── state/NetworkModeState.kt         # local-only cache, no cloud
└── res/...
```

## How to build it yourself

1. Install Android Studio (Koala/2024.1+ or newer).
2. Open the `LteToggle/` folder as a project — Android Studio will fetch
   the Gradle wrapper JAR and all dependencies (AGP 8.5.2, Kotlin 1.9.24,
   Shizuku API 13.1.5) automatically; this requires internet access, which
   this sandbox doesn't have.
3. Build → Build APK(s), or `./gradlew assembleDebug` from a terminal once
   the wrapper JAR has been fetched (Android Studio does this on first
   open; alternatively run `gradle wrapper` yourself with a local Gradle
   8.7+ install).
4. Install: `adb install app/build/outputs/apk/debug/app-debug.apk`, or
   copy the APK to the phone and open it there. This is a debug build
   signed with the Android debug key — fine for sideloading on your own
   device.

## Setup on your RMX3686

1. Install **Shizuku** (`moe.shizuku.privileged.api`) from
   https://shizuku.rikka.app/download/.
2. Settings → Developer options → enable **Wireless debugging** (Android
   11+ built-in method, no PC needed).
3. Open Shizuku → "Start via wireless debugging" → follow its pairing
   steps.
4. Open **LTE Toggle** → tap "Grant Shizuku permission" → allow.
5. Quick Settings → edit tiles → drag **LTE Only** in.
6. Tap the tile: toggles between LTE only and LTE/WCDMA/GSM.

Shizuku (ADB backend, non-rooted) does **not** survive a reboot — you must
reopen Shizuku and tap "start" again after every restart, exactly as noted
in Section 7. This is a Shizuku/Android limitation, not something this app
can work around without root.

## Test plan status (Section 21)

| # | Test | Status |
|---|------|--------|
| 1 | Install | Not run — no build artifact in this environment |
| 2 | Add tile to Quick Settings | Not run |
| 3–4 | Toggle actually changes mode | **Not run — this is the one that matters most.** The app will now correctly refuse to report success unless a read-back confirms the change, so a "Switched to ..." message is a real signal, not a guess — but whether it *ever* reaches `VERIFIED_MATCH` on your build, versus always landing on `VERIFIED_MISMATCH`/`VERIFY_UNAVAILABLE`, is exactly what running this test will tell you |
| 5 | Survives reboot | Not run (expect Shizuku to need restarting, see above) |
| 6 | Shizuku stop/restart detection | Not run — code path exists (`OnBinderDeadListener`) |
| 7 | Permission revoked | Not run — code path exists (reported as `SHIZUKU_PERMISSION_DENIED`) |
| 8 | Radio off | Not run — expect `REJECTED_BY_MODEM` or `SECURITY_EXCEPTION` from the framework, surfaced honestly, not verified |
| 9 | SIM removed | Not run — `defaultDataSubId()` will likely return `-1`; behavior with `subId = -1` passed to `createForSubscriptionId` is untested |
| 10 | Manual change reflected | Partially: `currentMode()` does a live read each time rather than trusting the cache, but whether realme's implementation reports the change back through `getAllowedNetworkTypesForReason()` promptly is unverified |
| 11 | Locked screen | Not run — TileService `onClick` normally requires the device to be unlocked for tiles marked interactive by default in newer Android; not specifically handled/tested here |
| 12 | After process kill | Not run — relies on standard TileService lifecycle; no custom persistence beyond `NetworkModeState` |

## Known limitations

- Not built or tested on real hardware in this session.
- The exact permission grant on shell/root for `MODIFY_PHONE_STATE` under
  realme UI 5.0 is assumed based on general AOSP/Shizuku behavior, not
  confirmed on your specific build.
- Dual-SIM slot selection UI (Section 11) is not implemented — the app only
  targets the default data subscription. If that's wrong for your setup,
  `NetworkModeController.defaultDataSubId()` is the one place to extend.
- No release/signed build is provided (Section 23) — only a debug-signed
  build is buildable from this project as-is; add your own signing config
  for a release APK.

## Privacy

No `INTERNET` permission, no analytics, no ads, no accounts, nothing sent
anywhere. `MODIFY_PHONE_STATE` is declared but will simply be unused/denied
unless the OS happens to grant it directly; Shizuku's provider entry is
required by the Shizuku API itself and does not grant any data access on
its own.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.localtools.ltetoggle"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.localtools.ltetoggle"
        // minSdk must be 30: TelephonyManager.setAllowedNetworkTypesForReason()/
        // getAllowedNetworkTypesForReason() (used unconditionally, unguarded, by
        // every controller in this app) were added in API 30. Declaring minSdk 26
        // while calling them with no Build.VERSION.SDK_INT guard would throw
        // NoSuchMethodError on API 26-29 devices. The target device (RMX3686,
        // Android 14 / API 34) is unaffected either way, but the manifest must
        // not claim support it doesn't actually have.
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        aidl = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    // Shizuku - lets the app run privileged calls (setAllowedNetworkTypesForReason)
    // via a process spawned with the shell (adb) or root (Sui) identity, without
    // the app itself requesting root or privileged/signature permissions.
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}

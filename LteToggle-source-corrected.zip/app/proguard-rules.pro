# Keep the AIDL-generated service interface and its Stub/Proxy classes intact,
# since they are invoked across process boundaries via Binder.
-keep class com.localtools.ltetoggle.service.INetworkModeService { *; }
-keep class com.localtools.ltetoggle.service.INetworkModeService$* { *; }
-keep class com.localtools.ltetoggle.telephony.NetworkModeUserService { *; }

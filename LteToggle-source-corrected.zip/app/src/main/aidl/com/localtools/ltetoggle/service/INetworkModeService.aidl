// This AIDL interface is entirely our own — not a copy of any hidden/internal
// Android framework AIDL. It is implemented by NetworkModeUserService, which
// Shizuku runs as a standalone process carrying the shell (or root) identity.
// Because it's our own interface, method transaction IDs are assigned by our
// own compiler at build time and are NOT dependent on any OEM/AOSP framework
// build, so there is nothing to reverse-engineer per device.
package com.localtools.ltetoggle.service;

interface INetworkModeService {

    // Simple liveness/identity check.
    boolean ping();

    // Returns the currently allowed network type bitmask for
    // ALLOWED_NETWORK_TYPES_REASON_USER on the given subscription id, or -1
    // if it could not be read (see lastError() for why).
    long getAllowedNetworkTypes(int subId);

    // Attempts to set the allowed network type bitmask for
    // ALLOWED_NETWORK_TYPES_REASON_USER on the given subscription id, and
    // independently VERIFIES the result by reading the value back
    // afterwards rather than trusting that the setter didn't throw.
    //
    // setAllowedNetworkTypesForReason() on TelephonyManager returns void —
    // the framework gives no return-value signal of success at all — so a
    // separate verification read is the only honest way to know whether
    // anything actually changed.
    //
    // Returns one of the NetworkModeServiceResult.* codes (see that class
    // in the telephony package for what each one means). Only
    // VERIFIED_MATCH represents a confirmed success; every other code is a
    // failure/unverified state and must be treated as such by callers.
    int setAllowedNetworkTypesVerified(int subId, long bitmask);

    // The bitmask actually read back by the most recent
    // setAllowedNetworkTypesVerified() call, or -1 if no read-back was
    // possible (i.e. result was SET_THREW or VERIFY_UNAVAILABLE).
    long lastVerifiedBitmask();

    // A short diagnostic string describing the last error/mismatch
    // encountered, or an empty string if the last operation was a clean
    // VERIFIED_MATCH.
    String lastError();

    // Shuts down this privileged process.
    void destroy();
}

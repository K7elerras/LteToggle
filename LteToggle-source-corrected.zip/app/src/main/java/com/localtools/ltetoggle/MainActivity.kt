package com.localtools.ltetoggle

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.localtools.ltetoggle.shizuku.ShizukuManager
import com.localtools.ltetoggle.shizuku.ShizukuState
import com.localtools.ltetoggle.state.NetworkModeState
import com.localtools.ltetoggle.telephony.NetworkModeController
import com.localtools.ltetoggle.telephony.NetworkModeResult
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var shizukuManager: ShizukuManager
    private lateinit var controller: NetworkModeController
    private lateinit var state: NetworkModeState
    private val bgExecutor = Executors.newSingleThreadExecutor()

    private lateinit var currentModeText: TextView
    private lateinit var shizukuStatusText: TextView
    private lateinit var targetSimText: TextView
    private lateinit var testButton: Button
    private lateinit var shizukuButton: Button
    private lateinit var fallbackButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        shizukuManager = ShizukuManager(applicationContext)
        controller = NetworkModeController(applicationContext, shizukuManager)
        state = NetworkModeState(applicationContext)

        currentModeText = findViewById(R.id.currentModeText)
        shizukuStatusText = findViewById(R.id.shizukuStatusText)
        targetSimText = findViewById(R.id.targetSimText)
        testButton = findViewById(R.id.testButton)
        shizukuButton = findViewById(R.id.shizukuButton)
        fallbackButton = findViewById(R.id.fallbackButton)

        testButton.setOnClickListener { runTestSwitch() }
        shizukuButton.setOnClickListener { handleShizukuButton() }
        fallbackButton.setOnClickListener { openPhoneInfoFallback() }

        shizukuManager.start { refreshStatus() }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        shizukuManager.stop()
        bgExecutor.shutdown()
        super.onDestroy()
    }

    private fun refreshStatus() {
        val subId = controller.defaultDataSubId()
        targetSimText.text = if (subId != -1) getString(R.string.sub_id_format, subId) else getString(R.string.sub_id_unknown)

        when (val shizukuState = shizukuManager.currentState()) {
            ShizukuState.NOT_INSTALLED -> {
                shizukuStatusText.text = getString(R.string.shizuku_not_installed)
                shizukuButton.text = getString(R.string.action_install_shizuku)
            }
            ShizukuState.NOT_RUNNING -> {
                shizukuStatusText.text = getString(R.string.shizuku_not_running)
                shizukuButton.text = getString(R.string.action_open_shizuku)
            }
            ShizukuState.PERMISSION_DENIED, ShizukuState.PERMISSION_NOT_YET_REQUESTED -> {
                shizukuStatusText.text = getString(R.string.shizuku_permission_needed)
                shizukuButton.text = getString(R.string.action_grant_permission)
            }
            ShizukuState.READY -> {
                shizukuStatusText.text = getString(R.string.shizuku_ready)
                shizukuButton.text = getString(R.string.action_shizuku_ready)
            }
        }

        bgExecutor.execute {
            val subId2 = controller.defaultDataSubId()
            val mode = controller.currentMode(subId2) ?: state.lastConfirmedMode
            runOnUiThread {
                currentModeText.text = mode?.label ?: getString(R.string.mode_unknown)
            }
        }
    }

    private fun handleShizukuButton() {
        when (shizukuManager.currentState()) {
            ShizukuState.NOT_INSTALLED -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                startActivity(intent)
            }
            ShizukuState.NOT_RUNNING -> {
                Toast.makeText(this, R.string.hint_start_shizuku, Toast.LENGTH_LONG).show()
            }
            ShizukuState.PERMISSION_DENIED, ShizukuState.PERMISSION_NOT_YET_REQUESTED -> {
                shizukuManager.requestPermission()
            }
            ShizukuState.READY -> {
                Toast.makeText(this, R.string.hint_already_ready, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun runTestSwitch() {
        testButton.isEnabled = false
        bgExecutor.execute {
            val subId = controller.defaultDataSubId()
            val current = controller.currentMode(subId) ?: state.lastConfirmedMode
            val target = (current ?: com.localtools.ltetoggle.telephony.NetworkMode.LTE_WCDMA_GSM).next()
            val result = controller.setMode(target, subId)
            runOnUiThread {
                testButton.isEnabled = true
                when (result) {
                    is NetworkModeResult.Success -> {
                        state.lastConfirmedMode = result.mode
                        currentModeText.text = result.mode.label
                        Toast.makeText(this, getString(R.string.switch_success, result.mode.label), Toast.LENGTH_SHORT).show()
                    }
                    is NetworkModeResult.Failure -> {
                        Toast.makeText(
                            this,
                            getString(R.string.toggle_failed, result.reason.name, result.detail),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    /** Manual fallback ONLY — never invoked automatically from the tile (Section 9). */
    private fun openPhoneInfoFallback() {
        val candidates = listOf(
            Intent("android.intent.action.MAIN").setClassName(
                "com.android.settings",
                "com.android.settings.Settings\$TestingSettingsActivity"
            ),
            Intent(Intent.ACTION_MAIN).apply {
                setClassName("com.android.settings", "com.android.settings.TestingSettings")
            },
            Intent("android.settings.SETTINGS")
        )
        for (intent in candidates) {
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, R.string.fallback_not_found, Toast.LENGTH_LONG).show()
    }
}

package com.localtools.ltetoggle.telephony

/** Honest outcome of an attempted network-mode change or query. Never a silent success. */
sealed class NetworkModeResult {
    data class Success(val mode: NetworkMode) : NetworkModeResult()
    data class Failure(val reason: FailureReason, val detail: String) : NetworkModeResult()
}

enum class FailureReason {
    SHIZUKU_NOT_INSTALLED,
    SHIZUKU_NOT_RUNNING,
    SHIZUKU_PERMISSION_DENIED,
    SERVICE_UNAVAILABLE,
    SECURITY_EXCEPTION,
    UNSUPPORTED,
    NO_SIM,
    RADIO_UNAVAILABLE,
    REJECTED_BY_MODEM,
    /** The setter call didn't throw, but a read-back afterward showed a
     *  different bitmask than requested — the change was not applied. */
    VERIFICATION_MISMATCH,
    /** The setter call didn't throw, but verification itself could not be
     *  performed (e.g. the read-back also needs READ_PRIVILEGED_PHONE_STATE
     *  and that failed). The outcome is genuinely unknown — never treat
     *  this as success. */
    VERIFICATION_UNAVAILABLE,
    TIMEOUT,
    UNKNOWN
}

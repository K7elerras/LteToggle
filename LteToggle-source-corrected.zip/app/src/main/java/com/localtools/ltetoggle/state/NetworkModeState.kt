package com.localtools.ltetoggle.state

import android.content.Context
import com.localtools.ltetoggle.telephony.NetworkMode

/**
 * Local-only (no cloud, no network) record of the last *confirmed* mode —
 * confirmed meaning the framework call reported success, not merely
 * "assumed after tapping the tile" (Section 12, Section 13).
 *
 * This is a cache to make the tile responsive; whenever a live read via
 * [com.localtools.ltetoggle.telephony.NetworkModeController.currentMode] is
 * possible, that live value should be preferred over this cache, since the
 * user (or another app) may have changed the mode through the hidden Phone
 * info screen in the meantime.
 */
class NetworkModeState(context: Context) {

    private val prefs = context.getSharedPreferences("network_mode_state", Context.MODE_PRIVATE)

    var lastConfirmedMode: NetworkMode?
        get() = prefs.getString(KEY_MODE, null)?.let { name ->
            runCatching { NetworkMode.valueOf(name) }.getOrNull()
        }
        set(value) {
            prefs.edit().apply {
                if (value == null) remove(KEY_MODE) else putString(KEY_MODE, value.name)
            }.apply()
        }

    companion object {
        private const val KEY_MODE = "last_confirmed_mode"
    }
}

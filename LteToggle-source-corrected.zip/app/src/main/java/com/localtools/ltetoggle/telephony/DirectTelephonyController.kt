package com.localtools.ltetoggle.telephony

import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

/**
 * Tries the operation the "normal" way, in this app's own process, with no
 * Shizuku involved at all — Section 6, decision-tree step 1.
 *
 * On virtually all consumer installs this will fail with SecurityException,
 * because MODIFY_PHONE_STATE is signature|privileged and a sideloaded APK
 * cannot hold it. This path exists so the app does the right thing (skip
 * Shizuku entirely) on the rare device/build where the permission actually
 * is granted, and so failure here is diagnosed honestly rather than assumed.
 *
 * setAllowedNetworkTypesForReason(int, long) returns void — it gives no
 * success/failure signal of its own. So, exactly like the Shizuku path,
 * this controller never reports success just because the call didn't
 * throw: it always follows up with an independent read-back via
 * getAllowedNetworkTypesForReason() and only reports success if that
 * read-back matches what was requested.
 */
class DirectTelephonyController(private val context: Context) {

    fun hasPermission(): Boolean =
        context.checkSelfPermission(android.Manifest.permission.MODIFY_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED

    fun defaultDataSubId(): Int {
        val id = SubscriptionManager.getDefaultDataSubscriptionId()
        return if (id != SubscriptionManager.INVALID_SUBSCRIPTION_ID) id else -1
    }

    fun setMode(mode: NetworkMode, subId: Int): NetworkModeResult {
        if (!hasPermission()) {
            return NetworkModeResult.Failure(
                FailureReason.SECURITY_EXCEPTION,
                "MODIFY_PHONE_STATE not granted to this app directly"
            )
        }

        val tm = try {
            val base = context.getSystemService(TelephonyManager::class.java)
            if (subId != -1) base.createForSubscriptionId(subId) else base
        } catch (t: Throwable) {
            return NetworkModeResult.Failure(FailureReason.UNKNOWN, "${t.javaClass.simpleName}: ${t.message}")
        }

        // Step 1: attempt the change. No return value to trust — void method.
        try {
            tm.setAllowedNetworkTypesForReason(
                TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER,
                mode.bitmask
            )
        } catch (e: SecurityException) {
            return NetworkModeResult.Failure(FailureReason.SECURITY_EXCEPTION, e.message ?: "SecurityException")
        } catch (t: Throwable) {
            return NetworkModeResult.Failure(FailureReason.UNKNOWN, "${t.javaClass.simpleName}: ${t.message}")
        }

        // Step 2: independently verify via read-back before claiming anything.
        val readBack = try {
            tm.getAllowedNetworkTypesForReason(TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER)
        } catch (t: Throwable) {
            return NetworkModeResult.Failure(
                FailureReason.VERIFICATION_UNAVAILABLE,
                "Set call did not throw, but the verification read requires " +
                    "READ_PRIVILEGED_PHONE_STATE and failed: ${t.javaClass.simpleName}: ${t.message}"
            )
        }

        return if (readBack == mode.bitmask) {
            NetworkModeResult.Success(mode)
        } else {
            NetworkModeResult.Failure(
                FailureReason.VERIFICATION_MISMATCH,
                "Requested ${mode.label} (0x${mode.bitmask.toString(16)}) but framework reports " +
                    "0x${readBack.toString(16)} afterward — change was not applied"
            )
        }
    }

    fun getMode(subId: Int): NetworkMode? {
        if (!hasPermission()) return null
        return try {
            val base = context.getSystemService(TelephonyManager::class.java)
            val tm = if (subId != -1) base.createForSubscriptionId(subId) else base
            val bitmask = tm.getAllowedNetworkTypesForReason(
                TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER
            )
            NetworkMode.fromBitmaskOrNull(bitmask)
        } catch (t: Throwable) {
            null
        }
    }
}

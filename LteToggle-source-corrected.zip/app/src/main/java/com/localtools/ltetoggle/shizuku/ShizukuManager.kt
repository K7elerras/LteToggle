package com.localtools.ltetoggle.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.localtools.ltetoggle.service.INetworkModeService
import com.localtools.ltetoggle.telephony.NetworkModeUserService
import rikka.shizuku.Shizuku

/** Everything the app can honestly know about Shizuku's current state. */
enum class ShizukuState {
    NOT_INSTALLED,
    NOT_RUNNING,
    PERMISSION_DENIED,
    PERMISSION_NOT_YET_REQUESTED,
    READY
}

private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
private const val REQUEST_CODE = 9100

/**
 * Thin wrapper around the Shizuku client API: detects install/running
 * state, requests permission, binds the [NetworkModeUserService] as a
 * privileged out-of-process service, and reports binder death / service
 * disconnects instead of silently pretending everything still works.
 */
class ShizukuManager(private val appContext: Context) {

    private var service: INetworkModeService? = null
    private var onStateChanged: ((ShizukuState) -> Unit)? = null

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(appContext.packageName, NetworkModeUserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("network_service")
        .debuggable(false)
        .version(1)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = if (binder.pingBinder()) {
                INetworkModeService.Stub.asInterface(binder)
            } else {
                null
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
        }
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            if (granted) bindService()
            onStateChanged?.invoke(currentState())
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        onStateChanged?.invoke(currentState())
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        // Shizuku itself died/stopped. Do NOT keep the old service reference around.
        service = null
        onStateChanged?.invoke(ShizukuState.NOT_RUNNING)
    }

    fun start(onStateChanged: (ShizukuState) -> Unit) {
        this.onStateChanged = onStateChanged
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        if (currentState() == ShizukuState.READY) bindService()
    }

    fun stop() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        runCatching { Shizuku.unbindUserService(userServiceArgs, serviceConnection, true) }
        service = null
    }

    fun currentState(): ShizukuState {
        if (!isShizukuAppInstalled()) return ShizukuState.NOT_INSTALLED
        if (!isShizukuRunning()) return ShizukuState.NOT_RUNNING
        return when {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuState.READY
            Shizuku.shouldShowRequestPermissionRationale() -> ShizukuState.PERMISSION_DENIED
            else -> ShizukuState.PERMISSION_NOT_YET_REQUESTED
        }
    }

    fun requestPermission() {
        if (isShizukuRunning() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    /** Returns a bound, ping-verified privileged service, or null if unavailable right now. */
    fun getServiceOrNull(): INetworkModeService? {
        val svc = service ?: return null
        return try {
            if (svc.asBinder().pingBinder() && svc.ping()) svc else {
                service = null
                null
            }
        } catch (t: Throwable) {
            service = null
            null
        }
    }

    private fun bindService() {
        if (currentState() != ShizukuState.READY) return
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (t: Throwable) {
            service = null
        }
    }

    private fun isShizukuAppInstalled(): Boolean = try {
        appContext.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun isShizukuRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }
}

package com.localtools.ltetoggle.telephony

import com.localtools.ltetoggle.shizuku.ShizukuManager
import com.localtools.ltetoggle.shizuku.ShizukuState

/**
 * Talks to [NetworkModeUserService] across process boundaries. Every method
 * maps unavailability/failure onto a specific, honest [FailureReason] —
 * never a silently-assumed success (Section 3, Section 13).
 *
 * The privileged setter (setAllowedNetworkTypesForReason) returns void, so
 * success here is defined purely by [NetworkModeServiceResult.VERIFIED_MATCH]
 * — i.e. the service independently read the new state back and it matched
 * what was requested. Every other result code (mismatch, unverifiable, or
 * threw) is treated as a failure, regardless of whether the RPC itself
 * completed without an exception.
 */
class ShizukuTelephonyController(private val shizukuManager: ShizukuManager) {

    fun setMode(mode: NetworkMode, subId: Int): NetworkModeResult {
        when (val state = shizukuManager.currentState()) {
            ShizukuState.NOT_INSTALLED ->
                return NetworkModeResult.Failure(FailureReason.SHIZUKU_NOT_INSTALLED, "Shizuku app not installed")
            ShizukuState.NOT_RUNNING ->
                return NetworkModeResult.Failure(FailureReason.SHIZUKU_NOT_RUNNING, "Shizuku service not running")
            ShizukuState.PERMISSION_DENIED, ShizukuState.PERMISSION_NOT_YET_REQUESTED ->
                return NetworkModeResult.Failure(FailureReason.SHIZUKU_PERMISSION_DENIED, "Permission not granted ($state)")
            ShizukuState.READY -> { /* proceed */ }
        }

        val service = shizukuManager.getServiceOrNull()
            ?: return NetworkModeResult.Failure(FailureReason.SERVICE_UNAVAILABLE, "User service not bound/alive")

        return try {
            when (val resultCode = service.setAllowedNetworkTypesVerified(subId, mode.bitmask)) {
                NetworkModeServiceResult.VERIFIED_MATCH ->
                    NetworkModeResult.Success(mode)

                NetworkModeServiceResult.VERIFIED_MISMATCH -> {
                    val detail = runCatching { service.lastError() }.getOrDefault("")
                    val readBack = runCatching { service.lastVerifiedBitmask() }.getOrDefault(-1L)
                    NetworkModeResult.Failure(
                        FailureReason.VERIFICATION_MISMATCH,
                        detail.ifBlank { "Framework read-back (0x${readBack.toString(16)}) did not match request" }
                    )
                }

                NetworkModeServiceResult.VERIFY_UNAVAILABLE -> {
                    val detail = runCatching { service.lastError() }.getOrDefault("")
                    NetworkModeResult.Failure(
                        FailureReason.VERIFICATION_UNAVAILABLE,
                        detail.ifBlank {
                            "setAllowedNetworkTypesForReason did not throw, but the verification " +
                                "read-back failed, so success cannot be confirmed"
                        }
                    )
                }

                NetworkModeServiceResult.SET_THREW -> {
                    val detail = runCatching { service.lastError() }.getOrDefault("")
                    NetworkModeResult.Failure(FailureReason.REJECTED_BY_MODEM, detail.ifBlank { "setAllowedNetworkTypesForReason threw" })
                }

                else ->
                    NetworkModeResult.Failure(FailureReason.UNKNOWN, "Unrecognized result code $resultCode")
            }
        } catch (e: android.os.DeadObjectException) {
            NetworkModeResult.Failure(FailureReason.SERVICE_UNAVAILABLE, "Binder died mid-call")
        } catch (e: SecurityException) {
            NetworkModeResult.Failure(FailureReason.SECURITY_EXCEPTION, e.message ?: "SecurityException from privileged process")
        } catch (t: Throwable) {
            NetworkModeResult.Failure(FailureReason.UNKNOWN, "${t.javaClass.simpleName}: ${t.message}")
        }
    }

    fun getMode(subId: Int): NetworkMode? {
        if (shizukuManager.currentState() != ShizukuState.READY) return null
        val service = shizukuManager.getServiceOrNull() ?: return null
        return try {
            val bitmask = service.getAllowedNetworkTypes(subId)
            if (bitmask < 0) null else NetworkMode.fromBitmaskOrNull(bitmask)
        } catch (t: Throwable) {
            null
        }
    }
}

package com.localtools.ltetoggle.telephony

import android.content.Context
import android.os.Process
import android.telephony.TelephonyManager
import com.localtools.ltetoggle.service.INetworkModeService

/**
 * Implementation of [INetworkModeService], instantiated by Shizuku in a
 * separate process created via app_process (see UserServiceArgs in
 * [com.localtools.ltetoggle.shizuku.ShizukuManager]).
 *
 * That process is NOT a normal app process — it runs with the Linux UID
 * Shizuku itself runs as: 2000 (shell), if Shizuku was started via
 * `adb shell` / wireless debugging (the only mechanism available on this
 * device, since it is not rooted), or 0 (root) if the backend is Sui.
 *
 * IMPORTANT — WHAT "SUCCESS" ACTUALLY MEANS HERE:
 * TelephonyManager.setAllowedNetworkTypesForReason(int, long) returns void.
 * The framework gives no success/failure signal from the call itself — not
 * throwing is not evidence that anything changed. So this class never
 * reports success based on "the call didn't throw". Instead, every set
 * operation:
 *   1. Calls the setter.
 *   2. If it throws, reports SET_THREW immediately — nothing is verified.
 *   3. If it doesn't throw, independently calls
 *      getAllowedNetworkTypesForReason() to read back the actual current
 *      value.
 *   4. Only if that read-back exactly matches what was requested is the
 *      result VERIFIED_MATCH. A non-matching read-back is VERIFIED_MISMATCH
 *      (the framework silently did not apply the change) — a failure, not
 *      a success. If the read-back itself fails (e.g. it also demands
 *      READ_PRIVILEGED_PHONE_STATE and that check fails even for this
 *      shell/root process), the result is VERIFY_UNAVAILABLE — again a
 *      failure/unknown state, never treated as success.
 *
 * Even VERIFIED_MATCH only proves the *framework's own bookkeeping* now
 * reports the new bitmask — it does not independently prove the RIL/modem
 * applied it at the radio level. That last mile can only be confirmed by
 * an actual test on the RMX3686 (see README test plan).
 */
class NetworkModeUserService : INetworkModeService.Stub() {

    @Volatile
    private var lastErrorMessage: String = ""

    @Volatile
    private var lastVerified: Long = -1L

    override fun ping(): Boolean = true

    override fun lastError(): String = lastErrorMessage

    override fun lastVerifiedBitmask(): Long = lastVerified

    override fun getAllowedNetworkTypes(subId: Int): Long {
        return try {
            val tm = telephonyManagerFor(subId)
            val value = tm.getAllowedNetworkTypesForReason(
                TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER
            )
            lastErrorMessage = ""
            value
        } catch (t: Throwable) {
            lastErrorMessage = "${t.javaClass.simpleName}: ${t.message}"
            -1L
        }
    }

    override fun setAllowedNetworkTypesVerified(subId: Int, bitmask: Long): Int {
        val tm = try {
            telephonyManagerFor(subId)
        } catch (t: Throwable) {
            lastErrorMessage = "Could not obtain TelephonyManager: ${t.javaClass.simpleName}: ${t.message}"
            lastVerified = -1L
            return NetworkModeServiceResult.SET_THREW
        }

        // Step 1: attempt the change. This method returns void — its only
        // signal is whether it throws.
        try {
            tm.setAllowedNetworkTypesForReason(
                TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER,
                bitmask
            )
        } catch (t: Throwable) {
            lastErrorMessage = "setAllowedNetworkTypesForReason threw: ${t.javaClass.simpleName}: ${t.message}"
            lastVerified = -1L
            return NetworkModeServiceResult.SET_THREW
        }

        // Step 2: independently verify by reading the value back. This is
        // the only part of this method that is allowed to produce a
        // "success" outcome.
        val readBack: Long = try {
            tm.getAllowedNetworkTypesForReason(TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER)
        } catch (t: Throwable) {
            lastErrorMessage = "Set call did not throw, but verification read-back failed " +
                "(likely needs READ_PRIVILEGED_PHONE_STATE): ${t.javaClass.simpleName}: ${t.message}"
            lastVerified = -1L
            return NetworkModeServiceResult.VERIFY_UNAVAILABLE
        }

        lastVerified = readBack
        return if (readBack == bitmask) {
            lastErrorMessage = ""
            NetworkModeServiceResult.VERIFIED_MATCH
        } else {
            lastErrorMessage = "Requested bitmask 0x${bitmask.toString(16)} but framework reports " +
                "0x${readBack.toString(16)} after the call — change was not applied"
            NetworkModeServiceResult.VERIFIED_MISMATCH
        }
    }

    override fun destroy() {
        Process.killProcess(Process.myPid())
    }

    /**
     * Bootstraps a system-level Context by hand, since this process was not
     * started as a regular Android app and has no Application/Activity
     * context of its own. This reflection is standard practice for Shizuku
     * "user service" code and is NOT subject to the hidden-API (@SystemApi)
     * restrictions that would block it inside a normal app process.
     */
    private fun systemContext(): Context {
        val activityThreadClass = Class.forName("android.app.ActivityThread")
        val activityThread = activityThreadClass.getMethod("systemMain").invoke(null)
        return activityThreadClass.getMethod("getSystemContext").invoke(activityThread) as Context
    }

    private fun telephonyManagerFor(subId: Int): TelephonyManager {
        val base = systemContext().getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        return if (subId != -1) base.createForSubscriptionId(subId) else base
    }
}

package com.localtools.ltetoggle.telephony

import android.content.Context
import com.localtools.ltetoggle.shizuku.ShizukuManager

/**
 * Implements the decision tree from Section 28:
 *   1. Try the direct public API in-process.
 *   2. Else try it through the Shizuku privileged user service.
 *   3. Else report failure honestly — never fake success.
 */
class NetworkModeController(context: Context, shizukuManager: ShizukuManager) {

    private val direct = DirectTelephonyController(context)
    private val shizuku = ShizukuTelephonyController(shizukuManager)

    fun defaultDataSubId(): Int = direct.defaultDataSubId()

    fun setMode(mode: NetworkMode, subId: Int): NetworkModeResult {
        if (direct.hasPermission()) {
            val result = direct.setMode(mode, subId)
            if (result is NetworkModeResult.Success) return result
            // Fall through to Shizuku only if the direct path failed for a
            // permission-shaped reason; otherwise surface the real error.
        }
        return shizuku.setMode(mode, subId)
    }

    /** Best-effort read of the real current mode, direct path first. */
    fun currentMode(subId: Int): NetworkMode? =
        direct.getMode(subId) ?: shizuku.getMode(subId)
}

package com.localtools.ltetoggle.tile

import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import com.localtools.ltetoggle.R
import com.localtools.ltetoggle.shizuku.ShizukuManager
import com.localtools.ltetoggle.state.NetworkModeState
import com.localtools.ltetoggle.telephony.NetworkMode
import com.localtools.ltetoggle.telephony.NetworkModeController
import com.localtools.ltetoggle.telephony.NetworkModeResult
import java.util.concurrent.Executors

/**
 * Real toggle tile (Section 5): reflects actual state, never claims success
 * it hasn't verified, and does no blocking work on the main thread.
 */
class LteToggleTileService : TileService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val bgExecutor = Executors.newSingleThreadExecutor()

    private lateinit var shizukuManager: ShizukuManager
    private lateinit var controller: NetworkModeController
    private lateinit var state: NetworkModeState

    override fun onCreate() {
        super.onCreate()
        shizukuManager = ShizukuManager(applicationContext)
        controller = NetworkModeController(applicationContext, shizukuManager)
        state = NetworkModeState(applicationContext)
    }

    override fun onStartListening() {
        super.onStartListening()
        shizukuManager.start { /* state changes just get picked up on next click/refresh */ }
        refreshTile()
    }

    override fun onStopListening() {
        shizukuManager.stop()
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        val tile = qsTile ?: return

        // Never block the tile/main thread on IPC or telephony work.
        tile.state = Tile.STATE_UNAVAILABLE
        tile.subtitle = getString(R.string.tile_working)
        tile.updateTile()

        bgExecutor.execute {
            val subId = controller.defaultDataSubId()
            val current = controller.currentMode(subId) ?: state.lastConfirmedMode
            val target = (current ?: NetworkMode.LTE_WCDMA_GSM).next()

            val result = controller.setMode(target, subId)

            mainHandler.post {
                when (result) {
                    is NetworkModeResult.Success -> {
                        state.lastConfirmedMode = result.mode
                        applyTileForMode(result.mode)
                    }
                    is NetworkModeResult.Failure -> {
                        // Do NOT switch to ON / claim the new mode. Keep prior known state.
                        applyTileForMode(state.lastConfirmedMode, error = true)
                        Toast.makeText(
                            applicationContext,
                            getString(R.string.toggle_failed, result.reason.name, result.detail),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    private fun refreshTile() {
        bgExecutor.execute {
            val subId = controller.defaultDataSubId()
            val mode = controller.currentMode(subId) ?: state.lastConfirmedMode
            mainHandler.post { applyTileForMode(mode) }
        }
    }

    private fun applyTileForMode(mode: NetworkMode?, error: Boolean = false) {
        val tile = qsTile ?: return
        when {
            error -> {
                tile.state = Tile.STATE_INACTIVE
                tile.subtitle = getString(R.string.tile_error)
            }
            mode == NetworkMode.LTE_ONLY -> {
                tile.state = Tile.STATE_ACTIVE
                tile.subtitle = mode.label
            }
            mode == NetworkMode.LTE_WCDMA_GSM -> {
                tile.state = Tile.STATE_INACTIVE
                tile.subtitle = mode.label
            }
            else -> {
                tile.state = Tile.STATE_INACTIVE
                tile.subtitle = getString(R.string.tile_unknown)
            }
        }
        tile.icon = Icon.createWithResource(this, R.drawable.ic_lte_tile)
        tile.label = getString(R.string.tile_label)
        tile.updateTile()
    }

    override fun onDestroy() {
        bgExecutor.shutdown()
        super.onDestroy()
    }
}

package com.localtools.ltetoggle.telephony

import android.telephony.TelephonyManager

/**
 * The two target modes from the spec (Section 4), expressed as
 * TelephonyManager network-type bitmasks — the modern (API 30+) replacement
 * for the old integer "preferred network mode" enum that Android 14 / the
 * hidden "Set Preferred Network Type" screen ultimately map onto.
 *
 * MODE A — "LTE only":      just the LTE bit.
 * MODE B — "LTE/WCDMA/GSM": LTE + UMTS (which covers WCDMA/HSPA/HSPA+) + GSM.
 *
 * NOTE ON CORRECTNESS: TelephonyManager.setAllowedNetworkTypesForReason() is
 * a *public* SDK method (added in API 30) that takes exactly this kind of
 * bitmask — it is not an OEM- or MediaTek-specific representation, and
 * realme UI 5.0 sits on top of stock AOSP telephony framework here, it does
 * not replace it. That is what makes this representation safe to hardcode,
 * unlike the raw integer "preferred_network_mode" values or raw AIDL
 * transaction codes, which *do* vary per build and cannot be hardcoded
 * without inspecting this specific device's framework.
 */
enum class NetworkMode(val label: String, val bitmask: Long) {
    LTE_ONLY(
        "LTE only",
        TelephonyManager.NETWORK_TYPE_BITMASK_LTE
    ),
    LTE_WCDMA_GSM(
        "LTE/WCDMA/GSM",
        TelephonyManager.NETWORK_TYPE_BITMASK_LTE
            or TelephonyManager.NETWORK_TYPE_BITMASK_GSM
            or TelephonyManager.NETWORK_TYPE_BITMASK_UMTS
    );

    fun next(): NetworkMode = if (this == LTE_ONLY) LTE_WCDMA_GSM else LTE_ONLY

    companion object {
        /** Best-effort match of a raw bitmask back to one of our two known modes. */
        fun fromBitmaskOrNull(bitmask: Long): NetworkMode? =
            entries.firstOrNull { it.bitmask == bitmask }
    }
}

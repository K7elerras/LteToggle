package com.localtools.ltetoggle.telephony

/**
 * Result codes returned by [com.localtools.ltetoggle.service.INetworkModeService.setAllowedNetworkTypesVerified].
 *
 * Defined as their own object (rather than only inside NetworkModeUserService)
 * so the client (ShizukuTelephonyController, running in this app's own
 * process) and the privileged implementation (NetworkModeUserService,
 * running in the separate Shizuku-spawned process) reference the same
 * integer constants at compile time. These are Kotlin `const val`s, so they
 * are inlined into both compiled call sites — there is no runtime
 * dependency between the two processes on this object being loaded in both,
 * only on both sides having been compiled from the same source.
 */
object NetworkModeServiceResult {
    /** setAllowedNetworkTypesForReason() did not throw, AND a subsequent
     *  getAllowedNetworkTypesForReason() read back the exact bitmask that
     *  was requested. This is the only code that represents a verified
     *  change — everything else must NOT be treated as success. */
    const val VERIFIED_MATCH = 0

    /** setAllowedNetworkTypesForReason() did not throw, but the read-back
     *  bitmask differs from what was requested. The call was accepted by
     *  the framework but the modem/framework did not end up in the
     *  requested state (or applied something else). This is a FAILURE,
     *  not a success — the setter not throwing is not proof of anything. */
    const val VERIFIED_MISMATCH = 1

    /** setAllowedNetworkTypesForReason() itself threw. Nothing was set,
     *  nothing was verified. */
    const val SET_THREW = 2

    /** setAllowedNetworkTypesForReason() did not throw, but the
     *  verification read (getAllowedNetworkTypesForReason) failed — most
     *  likely because it also requires READ_PRIVILEGED_PHONE_STATE and
     *  that check failed even for this shell/root process. The change is
     *  UNVERIFIED. This must be surfaced to the user as "we don't actually
     *  know if this worked", not treated as success. */
    const val VERIFY_UNAVAILABLE = 3
}
